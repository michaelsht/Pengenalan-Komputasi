# NIM/Nama  : 16521201/Michael Sihotang
# Tanggal   : 06 Oktober 2021
# Deskripsi : Problem 1, Menuliskan "Hello, World!" sebagai output

# Kamus
# belum diperlukan

# Algoritma
print("Hello, World!") # Menuliskan "Hello, World!" sebagai output